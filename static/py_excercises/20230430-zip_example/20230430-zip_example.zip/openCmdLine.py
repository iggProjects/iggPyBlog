import os

# clear screen (important to use colors)
os.system('cls')

# execute in console 
os.system('cmd /c "0-prototype-ZipExample.py"')
